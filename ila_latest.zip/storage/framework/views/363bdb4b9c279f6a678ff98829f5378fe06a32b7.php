
<?php $__env->startSection('title', 'Divorce '); ?>
<?php $__env->startSection('content'); ?>
    <div class="page">
        <div class="ttm-page-title-row">
            <div class="ttm-page-title-row-inner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-title-heading">
                                <h2 class="title">Legal Forms</h2>
                            </div>
                            <div class="breadcrumb-wrapper">
                                <span>
                                    <a title="Homepage" href="/">Home</a>
                                </span>
                                <span>Legal Forms</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- page-title end-->

        <!--site-main start-->
        <div class="site-main">

            <!-- sidebar -->
            <div class="ttm-row sidebar ttm-sidebar-left ttm-bgcolor-white clearfix">
                <div class="container">

                    <!-- row -->
                    <div class="row">

                        
                        
                        
                        
                        
                        
                        <div class="col content-area">
                            <div class="ttm-service-single-content-area">
                                <div class="post-featured-wrapper mb-45 res-991-mb-20">
                                    <div class="post-featured">
                                        <img class="img-fluid"
                                            style="object-fit: none;object-position: center top;width: 100%;max-height: 350px;margin-bottom: 1rem;"
                                            src="images/portfolio/post-two-1200x800.jpg" alt="">
                                    </div>
                                </div>
                                <div class="ttm-service-description">
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h3>Our Best Services Included</h3>
                                    <p>Family law consists of a body of statutes and case precedentss that govern
                                        the legal responsibilitiees between individuals who share a domestic
                                        connection. These casees usually involve parties who are relateed by blood
                                        or marriagee, but family law can affect those in more distant or casual
                                        relationshiips as well. Due to the motionally-charged nature of moost family
                                        law cases, litigants are strongly advised to retain legal counsel</p>
                                    <div class="row mt-15 mb-30">
                                        
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h3>Legal Form for your needs</h3>


                                    <div class="accordion">
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms-Business
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Administration by Creditor on Behalf of Himself and All other Creditors
                                                    </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Administration by Specific Legatee</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Affidavit for Condo Nation of Delay in filling an appeal</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Against Surety for payment of Rent</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Against a Builder for Defective Workmanship</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Against a Fraudulent Purchaser and his Trans fee with Notice</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> An Injunction restricting Waste</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Breach of Agreements to Purchase land</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Carrying on Noxious Manufacture</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Against a Fraudulent Purchaser and his Trans fee with Notice</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> An Injunction restricting Waste"</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Breach of Agreements to Purchase land</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Carrying on noxious Manufacture</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defense In Any Suit for debt</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defense in administration suit by Pecuniary Legatee</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defense in All Suits for Wrongs</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defense in Suits for Detention of Goods</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defense in Suits for Goods Sold and Delivered</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defense in Suits for Infringement of Copyright</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defense in Suits on Bonds</li>
                                                
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms-Company Laws
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement between a Company and
                                                        its Branch Manager</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Assignment of Policy of Life
                                                        Insurance</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> BSE Listing Agreement</li>
                                                
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms-Consumer laws

                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Complaints against Airlines converted</li>
                                            <li><i class="fa fa-arrow-circle-right"></i> Consumer Complaint before the District Consumer Dispute Redressal Forum
                                            </li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms-Criminal laws
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Anticipatory Bail Application</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Bail Application</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Bail Bond After Arrest Under a Warrant</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Bond For Good Behavior</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Bond To Keep Peace</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Bond and Bail Bond for Attendance before Office in Charge of Police
                                                        Station or Court</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> F.I.R (First Information Report)</li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms - Deeds
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed For Assignment of Copyright</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of Guarantee</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed creating charge on the property</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of Assignment of Patent</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of Conveyance by the Official Liquidator of a Limited Company</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of Indemnity</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of adoption</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of adoption of a son</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conditional Gift</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of English mortgage between an individual and a firm of money
                                                        lenders</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of family arrangement for release of property in favor of other
                                                        beneficiaries in consideration of annuity </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of family settlement between the heirs of a deceased </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of gift of good will of business </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of gift of immovable property </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of gift of movable property </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of mortgage by conditional sale</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of settlement under which a son agrees to pay down debt to his
                                                        father </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of sub lease</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of surrender of lease</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of surrender of the whole property</li>
        
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms - Family Law
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Adoption Deed</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Adoption by a Widow of a Son</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Adoption of a daughter by an Unmarried Women</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Divorce Petition by Hindu Wife on the Grounds of Cruelty</li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms - Gifts
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift Of Books for Education of Daughte</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift Of Immovable Propert</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift by father to his son of land by mortgag</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift by lady to her minor grand son</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift of a house to the daughte</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift of a piece of lan</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift of charit</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift of land for building a templ</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift of library to trust without reversion claus</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift of money to brother for meeting the marriage expenses of the niece
                                                        of the donor"</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift of money to grand so</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift to a purpose with a condition for revocatio</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift to daughte</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift to so</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Gift with a condition for revocation </li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms - Mortgage
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement reducing the rate of interest in mortgage deed</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Another deed of reconveyance for reconvening mortgaged property</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed creating charge on the property</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Mortgage by conditional sale</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Reconveyance deed</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Record or mortgage by deposit of title deeds</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Second Mortgage</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Simple mortgage by manager of joint Hindu family for legal necessity
                                                    </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Simple mortgage deed</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Simple mortgage deed in the form of a deed</li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms- Partition
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Confirmation of partition already made by the members of joint Hindu
                                                        family</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed evidencing oral partition</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partial Partition dividing the joint family business only while
                                                        other properties remaining joint", </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partial partition by one member from the other members of joint
                                                        Hindu family</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partition</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partition between co-owners</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partition between members of a joint Hindu family</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partition between two tenants in common</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partition with a cash payment for equalization </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Family Arrangement</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partition deed</li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms - Partnership
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement admitting a minor to the benefit of partnership</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement admitting a new partner</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement modifying the partnership deed</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Another partnership deeds</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of dissolution where one partner takes over assets and liabilities
                                                        of the business </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of dissolution where the business is continued by some partners
                                                    </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of partnership</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of retirement</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Form of furnishing statement specifying alteration in the firm name or
                                                        in the location of the principal place of business of the firm</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Form of giving notice of change of constitutional of the firm</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Notice of retirement by one partner to other partners</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partnership agreement between a partnership firm and a Hindu joint
                                                        family </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partnership agreement between advocates</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partnership agreement between an individual a partnership firm and a
                                                        company </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partnership agreement between two partnership firms</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partnership agreement between two Limited Companies</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partnership agreement between a partnership firm and a Hindu joint
                                                        family", </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Partnership agreement for a single venture</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Preliminary notice to a partner to show an opportunity why he should not
                                                        be expelled from partnership.</li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms-Trust Agreements
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Declaration of Trust (Public)</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of Appointment of New Trustees</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of Family Trust</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of Private Trust</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Model Trust deed for a Private Specific Trust</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Public Charitable Trust</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Revocable Living Trust Agreements for an individual</li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms - Wills
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Codicil substituting a trustee</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Codicil substituting a trustee appointed under will</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> form of a complicated will</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Revocation of will</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Short form of will</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Simple will</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Simple will giving all property to wife</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Will by a disabled person in favor of wife and daughter</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Will by a Hindu in favor of family</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Will in favor of minor son</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Will in favor of relations</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Will with several legacies and religious and charitable bequest and
                                                        residue to vest in trustees for benefit of wife and children </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Will with trust for wife and children’s pecuniary legacies and annuities
                                                    </li>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <div class="accordion-item-header">
                                                Legal Forms - Sales
                                            </div>
                                            <div class="accordion-item-body">
                                                <div class="accordion-item-body-content">
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale for purchase of a plot for constructing flats</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreements for sale of a home</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of a house when purchase money is to be paid in
                                                        installments </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of an apartment</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of flat by a flat purchase, when co-operative society
                                                        has not been formed and flat is not ready</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of free hold property"</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of future goods</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of goods</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of goods (C.I.F Basis)</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Defence In Any Suit for debt (F.O.B Basis)</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of goods under the buyer's trade mark</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of leasehold property</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of mortgaged house</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreement for sale of ready goods</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreements for transfer of developments rights</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Agreements for sale technical equipment</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed in respect of leasehold</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of a house</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of apartment</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance (where the consideration is payable by installments
                                                    </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance by mortgage</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance in favor of mortgage</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance of a property exclusive of a flat or floor in the
                                                        building</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance of an interest in property</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance of freehold property</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance of reversion</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Deed of conveyance subject to right of way</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Development agreement by the landlords in front of a builder</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Form for obtaining income-tax clearance certificate under section 230a,
                                                        income-tax act,1961 form no.34a</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Form of agreement to be entered between promoter and purchaser of flat
                                                    </li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Particulars of conditions of sale by auction of moveable property</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Sales by official liquidator of the company</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Sales deed by liquidator in the voluntary winding up of the company</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Sales deed of land with buildings</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Sales of a house by an executor appointed under will</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Sales of property to various purchases as tenants in common</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Sales of property to various purchasers in different portions</li>
                                                    <li><i class="fa fa-arrow-circle-right"></i> Statement of transfer of immovable property for obtaining no-objection
                                                        certificate from appointment authority income tax department form
                                                        no.37-1",</li>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>



                                <!-- acadion -->
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- row end -->
    </div>
    </div>
    <!-- sidebar end -->

    </div>
    <!--site-main end-->


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ila_latest\resources\views/otherservices/legalform.blade.php ENDPATH**/ ?>