
<?php $__env->startSection('title', 'Paralegal Services '); ?>
<?php $__env->startSection('content'); ?>
    <div class="page">
        <!-- page-title -->
        <div class="ttm-page-title-row">
            <div class="ttm-page-title-row-inner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-title-heading">
                                <h2 class="title">Paralegal Services</h2>
                            </div>
                            <div class="breadcrumb-wrapper">
                                <span>
                                    <a title="Homepage" href="<?php echo e(url('/')); ?>">Home</a>
                                </span>
                                <span>About Us</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- page-title end-->
        <section class="ttm-row ttm-grid-view pb-60 res-991-pb-30 clearfix">
            <div class="container">
                <div class="main">

                    <!--cards -->
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/aadhaar.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>Aadhaar Card Services</p>
                   
                   </div>
                   </div>
                   <!--cards -->
                   
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/pancard.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>Pancard Services</p>
                   
                   </div>
                   </div>
                   <!--cards -->
                   
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/birth.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>Birth & Death Certificate</p>
                   
                   </div>
                   </div>
                   <!--cards -->
                   
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/willgifting.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>Will & Gift Writing</p>
                   
                   </div>
                   </div>
                   <!--cards -->
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/legalnotice.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>Legal Notice</p>
                   
                   </div>
                   </div>
                   <!--cards -->
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/ecpatta.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>EC,Patta & Land Verification</p>
                   
                   
                   </div>
                   </div>
                   <!--cards -->
                   
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/educational.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>Educational Issues</p>
                   
                   </div>
                   </div>
                   <!--cards -->
                   
                   
                   <div class="card">
                   
                   <div class="image">
                      <img src="<?php echo e(asset('images/affidavit.png')); ?>">
                   </div>
                   <div class="title">
                   
                   </div>
                   <div class="des">
                    <p>Affidavits</p>
                   
                   </div>
                   </div>
                   </div>
                
            </div>
        </section>
    </div>
    <!--site-main end-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ila_latest\resources\views/paralegal/index.blade.php ENDPATH**/ ?>